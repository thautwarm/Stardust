from setuptools import setup, find_packages
setup(
    name = 'freestyle',
    version = '0.1',
    keywords='collections',
    description = "don't you have freestyle?",
    license = 'MIT License',
    url = 'twshere@outlook.com',
    author = 'tw',
    author_email = 'yaoxiansamma@gmail.com',
    packages = find_packages(),
    include_package_data = True,
    platforms = 'any',
    install_requires = [],
)
